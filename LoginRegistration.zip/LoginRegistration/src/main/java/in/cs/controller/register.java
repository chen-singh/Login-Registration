package in.cs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import in.cs.dbconnection.DBConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
@WebServlet("/regForm")
public class register extends HttpServlet {
	
@Override
protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException {
	
	
	PrintWriter out=res.getWriter();
	res.setContentType("text/html");
	
	
	String myname=req.getParameter("name");
	String myemail=req.getParameter("email");
	String mypas=req.getParameter("pas");
	String mydob=req.getParameter("dob");
	String mycity=req.getParameter("city");
	String mycountry=req.getParameter("country");
	 
	
	try {
		Connection con=DBConnection.getConnection();
		String sql="INSERT INTO register VALUES (?,?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		
		ps.setString(1, myname);
		ps.setString(2, myemail);
		ps.setString(3, mypas);
		ps.setString(4, mydob);
		ps.setString(5, mycity);
		ps.setString(6, mycountry);
		int count =ps.executeUpdate();
		if(count>0) {
			
			
			out.print("<h3 style='color:green'> Successfully inserted  </h3> ");
			RequestDispatcher rd=req.getRequestDispatcher("/log.html");
			
			rd.include(req, res);
		
		}else {
			out.print("<h3 style='color:red'>Login failed </h3>");
			RequestDispatcher rd=req.getRequestDispatcher("/reg.html");
			rd.include(req, res);
		
		}
	
	

    }catch(Exception e) {
	e.printStackTrace();
   }
   }}