package in.cs.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import in.cs.bean.User;
import in.cs.dbconnection.DBConnection;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/logForm")
public class log extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req,HttpServletResponse res) throws IOException {
		PrintWriter out=res.getWriter();
		res.setContentType("text/html");
		
		
		String myemail=req.getParameter("email");
		String mypas=req.getParameter("pas");
		
		try {
			Connection con=DBConnection.getConnection();
			String sql="SELECT * FROM register WHERE email=? AND pas=?";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, myemail);
			ps.setString(2, mypas);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
				User us=new User();
				us.setName(rs.getString("name"));
				us.setEmail(rs.getString("email"));
				us.setCity(rs.getString("city"));
				us.setDate(rs.getString("date"));
				us.setCountry(rs.getString("country"));
				
				HttpSession session=req.getSession();
				session.setAttribute("session_user",us);
				
				RequestDispatcher rd=req.getRequestDispatcher("/profile.jsp");
				rd.include(req, res);
				
				
			}else {
				out.print("<h3 style='color:red'>Login failed  <h3>");
				RequestDispatcher rd=req.getRequestDispatcher("/log.html");
				rd.include(req, res);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
